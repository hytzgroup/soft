#### Build:

1: Install Node.js and NPM on your computer
2: Run command "npm install -g bower grunt-cli"
3: Run "bower install" to install dependencies
4: Run "grunt build:angular" to build project
5: Run "npm start" to start server

#### Run "grunt build:angular" to build app with minified css and js.

#### Preview without "Build":

1: Put all the files on a local server (must include the "app" and "libs" folder)
2: Open "http://localhost/app/" in browser
