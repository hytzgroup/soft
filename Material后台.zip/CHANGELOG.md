## Release v1.0.1:

#### Features:

 - Add HTML version

#### Bugfixes:

 - Update angular-material to 0.9.0-rc3 to fix the double click event on mobile.
